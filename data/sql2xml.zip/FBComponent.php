<?php
// Library about Firebird Database
// Copyright(c) 2005, James Lee
// Portion (c) Ryulib
// Contact : james.962@gmail.com
// $ID:FBComponent.php July 4 10:00 Build 15

class TFBDatabase
  {
      var $link_id;
      var $DatabaseName;
      var $UserName;
      var $Password;
//      var $Charset; These are optionable. If you wish, add it.
//      var $Buffers;
//      var $Dialect;
//      var $Role;
      
      var $Errcode;
      var $Errmsg;
      var $Connected;
      
      function TFBDatabase($DatabaseName, $UserName, $Password)
      {
        $this->DatabaseName = $DatabaseName;
        $this->UserName = $UserName;
        $this->Password = $Password;
//        $this->Charset = $Charset;
//        $this->Buffers = $Buffers;
//        $this->Dialect = $Dialect;
//        $this->Role = $Role;
      }
      
      function Open()
      {
        $this->link_id = ibase_connect($this->DatabaseName, $this->UserName, $this->Password);
        if (!$this->link_id) {
          $this->Errcode = ibase_errcode();
          $this->Errmsg  = ibase_errmsg();
          $this->Connected = FALSE;
          }
        else {$this->Connected = TRUE;}
      }
      
      function Affected()
      {
      return ibase_affected_rows($this->link_id);
      }
      
      function Close()
      {
      ibase_close($this->link_id);
      $this->Connected= FALSE;
      }
  }//end of class
  
class TQuery
  {
    var $Database;

    var $SQL;

    var $RecordCount;
    
    var $result;
    
    var $Field_info = array();
    
    var $FieldCount;
    
    var $Recperpage;
    
     
    
    function TQuery($Database)
    {
      $this->Database = $Database;
    }
    
    function ibase_num_rows($query) //I have pick it from bg_idol@hotmail.com
    { 
      $i = 0;
      while (ibase_fetch_row($query)) {
       $i++;
        }
      return $i;
    }
    
    function Get_field_info($query)
    {
     $this->Fieldcount = ibase_num_fields($query);
       for ($i = 0; $i < $this->Fieldcount; $i++) {
       $col_info = ibase_field_info($query, $i); 
       $this->Field_info[$i]['name']=$col_info['name'];
       $this->Field_info[$i]['alias']=$col_info['alias']; 
       $this->Field_info[$i]['relation']=$col_info['relation']; 
       $this->Field_info[$i]['length']=$col_info['length']; 
       $this->Field_info[$i]['type']=$col_info['type']; 
   }

    }
  function Open()
  {
  $this->result = ibase_query($this->Database->link_id, $this->SQL);
  $this->RecordCount= $this->ibase_num_rows($this->result);
  
  $this->result = ibase_query($this->Database->link_id, $this->SQL);
  
  $this->Get_field_info($this->result);
  }
  
  function Show_Page($page,$Id)
  {
    $i = 0;
    $norecord = ($page - 1) * $this->Recperpage;
    if ($norecord){
    $j=0;
    while($j < $norecord and ibase_fetch_row($this->result)){
    $j++;}
    }
   
    
    while ($onerow= ibase_fetch_row($this->result) and $i < $this->Recperpage){
    echo "<".$Id.">\n";
    foreach($onerow as $key => $value) {
     echo "<".$this->Field_info[$key]['name'].">";
     echo $value;
     echo "</".$this->Field_info[$key]['name'].">\n";
     }
  echo "</".$Id.">\n"; 
  $i++;
    }
 
   } 
    
  function Close()
  {
  ibase_free_result($this->result);
  }
  
}//end of class
    
    
     