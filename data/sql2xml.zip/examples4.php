<?php
// ���̺귯�� �̿� ����
// �ۼ��� : 2005�� 7�� 4��
// �ۼ��� : James Lee

header("Content-Type: text/xml");
echo "<?xml version='1.0' encoding='euc-kr'?>";

include ("Configuration.php");
include ("FBComponent.php");

if (!isset($page))
  $page = 1;

$Database = new TFBDatabase($yourdb, $user, $password);
$Database->Open();

$TestQry = new TQuery($Database);
$TestQry->SQL = "select * from zipcode";
$TestQry->Open();
$TestQry->Recperpage=10;
echo "<root>\n";
$TestQry->Show_Page($page,"result");
echo "</root>";
$TestQry->Close();
$Database->Close();
  

?>


