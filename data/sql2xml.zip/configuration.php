<?php

$yourdb ='127.0.0.1:c:/php/bbs.fdb';
$user = 'SYSDBA';
$password = 'masterkey';
$charset ='KSC5601';

?>